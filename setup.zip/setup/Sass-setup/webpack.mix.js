let mix = require("laravel-mix");

mix.sass("src/main.scss", "public/style.css");
