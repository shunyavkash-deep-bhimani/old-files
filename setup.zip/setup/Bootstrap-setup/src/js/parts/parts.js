//fancybox js
require("@fancyapps/ui");

export class Parts{

    init() {

    }


}
