// <script src="https://rglhpcjp-5500.inc1.devtunnels.ms/createMe-js.js"></script>

function isMobileDevice() {
  return /Mobi|Android|iPhone|iPad|iPod|Opera Mini|IEMobile/i.test(navigator.userAgent);
}

function deviceNotRotate() {
  document.querySelectorAll(".bg-video-section").forEach(function (bgVideoSection) {
    bgVideoSection.querySelectorAll(".iframe-video").forEach(function (iframeVideo) {
      iframeVideo.classList.remove("device-rotate");
    });
  });
}

function deviceRotate() {
  document.querySelectorAll(".bg-video-section").forEach(function (bgVideoSection) {
    bgVideoSection.querySelectorAll(".iframe-video").forEach(function (iframeVideo) {
      iframeVideo.classList.add("device-rotate");
    });
  });
}

if (isMobileDevice()) {
  console.log("Mobile device detected");

  if (window.matchMedia("(orientation: portrait)").matches) {
    console.log("Portrait mode");
    deviceNotRotate();
  } else {
    console.log("Landscape mode");
    deviceRotate();
  }

  window.matchMedia("(orientation: portrait)").addEventListener("change", (e) => {
    location.reload();

    if (e.matches) {
      console.log("Portrait mode");
      deviceNotRotate();
    } else {
      console.log("Landscape mode");
      deviceRotate();
    }
  });
} else {
  console.log("Desktop device detected");
}

if (document.querySelector(".hero-video-slider.splide")) {
  var heroVideoSlider = new Splide(".hero-video-slider.splide", {
    type: "loop",
    pagination: false,
    arrows: false,
    speed: 1000,
    autoplay: true,
    interval: 8000,
  });

  var heroInnerSlider = new Splide(".hero-inner-slider.splide", {
    type: "fade",
    arrows: false,
    speed: 1000,
  });

  heroVideoSlider.sync(heroInnerSlider);
  heroVideoSlider.mount();
  heroInnerSlider.mount();
}
